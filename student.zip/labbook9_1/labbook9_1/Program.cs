﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labbook9_1
{
    class Program
    {
        static Dictionary<string, string> dictionary = new Dictionary<string, string>();
        static void Main(string[] args)
        {
            AddMethod();
            Display();
            Edit();
            Remove();
            Console.ReadLine();
        }

        static void AddMethod()
        {
            try
            {
                dictionary.Add("liki", "miki");

                dictionary.Add("kiki", "niki");

                dictionary.Add("jiki", "ciki");

                dictionary.Add("diki", "riki");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }


        static void Display()
        {
            foreach (var obj in dictionary)
            {
                Console.WriteLine(obj);
            }
        }

        static void Edit()
        {
            dictionary["kiki"] = "hiki";
            foreach (var obj in dictionary)
            {
                Console.WriteLine(obj);
            }
        }

        static void Remove()
        {
            dictionary.Remove("diki");
            foreach (var obj in dictionary)
            {
                Console.WriteLine(obj);
            }
        }

    }
}
